import pygame #importing the library
import sys #manipulates stuff on desktop
from bullet import Bullet
from space_ship import SpaceShip
class Game:

    def __init__(self):

        #creates the main window
        pygame.init() #initializing the module
        self._display = pygame.display.set_mode((800,800)) #creates the window and sets its size
        self._clock = pygame.time.Clock() #creates a clock
        pygame.display.set_caption('Space Invaders') #allows us to change the text of the window

        #creates a surface - like creating a table
        self._space_surface = pygame.Surface((800,800)) #want the surface to be the full window

        #create spaceship
        self._space_ship = SpaceShip("assets/DurrrSpaceShip.png", 400, 800) #takes (image,x,y)
        print(self._space_ship)

        #dictionary of all bullets 
        self._all_bullet = pygame.sprite.Group()

    def run(self): #function to run the game
        while True: #game will run in a large while loop

            #CHECKS FOR EVENTS - loops through dictionary of events to see if the game is quit or not
            for event in pygame.event.get(): #returns a dictionary of all events in the game whether game is closed, exited, etc
                if event.type == pygame.QUIT: #if event occurs
                    pygame.quit() #stop pygame
                    sys.exit() #closes the window

                if event.type == pygame.MOUSEBUTTONDOWN: #will shoot using mousebutton
                    current_ship_location = self._space_ship.get_position() #grabs ship current location
                    print(current_ship_location)
                    bullet_object = Bullet(current_ship_location[0] + 40, current_ship_location[1] + 10) #takes in x and y coordinate
                    self._all_bullet.add(bullet_object) #adds the bullet object to bullet dictionary
                    print(self._all_bullet)

            keys = pygame.key.get_pressed() #prints the status of every key, whether it is being pressed
            if keys[pygame.K_d]:
                self._space_ship.move("d")
                # print(keys[pygame.K_d])
            if keys[pygame.K_a]:
                self._space_ship.move("a")
                # print(keys[pygame.K_a])
            if keys[pygame.K_w]:
                self._space_ship.move("w")
                # print(keys[pygame.K_w])
            if keys[pygame.K_s]:
                self._space_ship.move("s")
                # print(keys[pygame.K_s])
            # print(keys)


            self._display.blit(self._space_surface,(0,0)) #allows to place surface -like paper on table
            self._space_surface.blit(pygame.image.load("assets/OuterSpace.png"), (0,0)) #Places on surface - like drawing on paper
            self._space_surface.blit(self._space_ship.get_surface(), self._space_ship.get_position()) #place ship on surface
            self._all_bullet.draw(self._space_surface) #draw the bullets onto the screen 
            self._all_bullet.update() #

            #updates window
            pygame.display.update() #updates the screen
            self._clock.tick(60) #sets to 60fps

my_game = Game()
my_game.run()



# https://www.pygame.org/docs/ref/key.html